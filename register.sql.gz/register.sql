-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2019 at 08:35 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `ID` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`ID`, `name`, `comment`) VALUES
(21, 'supriya', ''),
(22, 'supriya', '<script>\r\nalert(1);\r\n</script>'),
(24, 'Aayu123', 'comment'),
(25, 'Sakshi', '<script>document.location = \'stealer.php\';</script>');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `username` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `visitor` varchar(20) NOT NULL,
  `comments` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`username`, `email`, `visitor`, `comments`) VALUES
('Aayu123', 'aayu@gmail.com', 'Proffeser', 'food was amazing'),
('su', 'supsws@gmail.com', '', 'great time and food!!');

-- --------------------------------------------------------

--
-- Table structure for table `fooditems`
--

CREATE TABLE `fooditems` (
  `item_id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `ItemOption` varchar(50) NOT NULL,
  `price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fooditems`
--

INSERT INTO `fooditems` (`item_id`, `name`, `ItemOption`, `price`) VALUES
(6, 'Vegetable Patty With Coleslaw', 'Burgers', 30),
(7, 'Fajita Paneer & Vegetable', 'Burgers', 30),
(8, 'Chicken Patty With Vegetable', 'Burgers', 30),
(9, 'Chicken Cut in Mexican Style', 'Burgers', 30),
(10, 'Mixed Vegetable With Cheese', 'Burgers', 30),
(11, 'Grilled Paneer & Vegetable', 'Burgers', 30),
(12, 'Chicken Sausage With Mustard', 'Burgers', 30),
(13, '(Black Forest/Truffle/Noughat)', 'Desserts', 30),
(14, 'Apple Pie With Ice Cream', 'Desserts', 30),
(15, 'Strawberry Milk Shake', 'Cold Beverages', 30),
(16, 'Chocolate Milk Shake', 'Cold Beverages', 30),
(17, '(Mint With Cheese Tomato)', 'Sandwiches', 30),
(18, '(Fresh Tomatoes, Cucumber)', 'Sandwiches', 30),
(19, 'Pineapple Flavoured Cream', 'Exotic Cakes', 300),
(20, 'A Chocolate Sponge Base', 'Exotic Cakes', 30),
(21, 'Butter Scotch', 'Ice Creams', 30),
(22, 'Pineapple', 'Ice Creams', 30),
(23, 'Black Forest', 'Ice Creams', 30),
(24, 'Chocolate with Orange', 'Ice Creams', 30);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'aayu', 'abc@gmail.com', 'kakssla,'),
(24, 'supriya', 'supsws@gmail.com', 'aayu'),
(25, 'khitoja', 'hello@123', 'djixsuifh'),
(26, 'Aayu123', 'tyu@123', 'aayu'),
(27, 'Sakshi', 'sha@yahoo.in', 'qwerty'),
(28, 'qwerty', 'kumari@yahoo.in', 'saloni');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `fooditems`
--
ALTER TABLE `fooditems`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `fooditems`
--
ALTER TABLE `fooditems`
  MODIFY `item_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
